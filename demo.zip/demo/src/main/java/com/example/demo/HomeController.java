package com.example.demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.Key;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HomeController {

    @Autowired
    private UserService userService;

    private static final String ALGORITHM = "AES";
    private static final String KEY = "1Hbfh667adfDEJ78";

    @GetMapping("/")
    public String home() {
        return "register";
    }

    @GetMapping("/about")
    public String about() {
        return "about";
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact";
    }

    @GetMapping("/brmstools")
    public String brmstools(Model model) {
        List<Server> servers = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Raj\\Downloads\\demo (1)\\demo\\src\\main\\resources\\servers.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[0].trim();
                String url = parts[1].trim();
                Server server = new Server(name, url);
                servers.add(server);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        model.addAttribute("servers", servers);
        return "brmstools";
    }

    @GetMapping("/status")
    public String status(Model model) {
        List<ServerStatus> serverStatusList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Raj\\Downloads\\demo (1)\\demo\\src\\main\\resources\\servers.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[0].trim();
                String url = parts[1].trim();
                try {
                    URL serverUrl = new URL(url);
                    HttpURLConnection conn = (HttpURLConnection) serverUrl.openConnection();
                    conn.setRequestMethod("HEAD");
                    int responseCode = conn.getResponseCode();
                    boolean isUp = (200 <= responseCode && responseCode <= 399);
                    Date lastStatusCheck = new Date(System.currentTimeMillis());
                    ServerStatus serverStatus = new ServerStatus(name, isUp, lastStatusCheck, url);
                    serverStatusList.add(serverStatus);
                } catch (MalformedURLException e) {
                    // Handle MalformedURLException
                    e.printStackTrace();
                } catch (IOException e) {
                    // Handle IOException
                    boolean isUp = false;
                    Date lastStatusCheck = new Date(System.currentTimeMillis());
                    ServerStatus serverStatus = new ServerStatus(name, isUp, lastStatusCheck, url);
                    serverStatusList.add(serverStatus);
                }
            }
        } catch (IOException e) {
            // Handle IOException
            e.printStackTrace();
        }
        model.addAttribute("serverStatusList", serverStatusList);
        return "status";
    }

    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String processRegistrationForm(@ModelAttribute("user") User user) throws IOException {
        userService.saveUserToFile(user);
        return "redirect:/login";
    }
    
}