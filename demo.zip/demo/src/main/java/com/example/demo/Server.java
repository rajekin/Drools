package com.example.demo;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;


public class Server {

    private String name;
    private String url;

    public Server(String name, String url) {
        this.name = name;
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }
}


