package com.example.demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class UserService {

    private UserRepository userRepository;
    
    private String fileName = "users.txt";
    
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public void register(User user) throws IOException {
        String encryptedPassword = encryptPassword(user.getPassword());
        user.setPassword(encryptedPassword);
        userRepository.save(user);
        saveUserToFile(user);
    }

    public User findByUsername(String username) throws IOException {
        List<User> users = getUsersFromFile();
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    void saveUserToFile(User user) throws IOException {
        FileWriter fileWriter = new FileWriter(fileName, true);
        PrintWriter printWriter = new PrintWriter(fileWriter);
        printWriter.println(user.getUsername() + "," + user.getPassword());
        printWriter.close();
    }

    private List<User> getUsersFromFile() throws IOException {
        List<User> users = new ArrayList<>();
        FileReader fileReader = new FileReader(fileName);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            String[] parts = line.split(",");
            String username = parts[0].trim();
            String encryptedPassword = parts[1].trim();
            User user = new User(username, encryptedPassword);
            users.add(user);
        }
        bufferedReader.close();
        return users;
    }

    private String encryptPassword(String password) {
        // Add encryption logic here
        return password;
    }
    
    private String decryptPassword(String encryptedPassword) {
        // Add decryption logic here
        return encryptedPassword;
    }
}
