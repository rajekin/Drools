package com.example.demo;

import java.util.Date;

public class ServerStatus {
    private String name;
    private boolean isUp;
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isUp() {
		return isUp;
	}

	public void setUp(boolean isUp) {
		this.isUp = isUp;
	}

	public Date getLastStatusCheck() {
		return lastStatusCheck;
	}

	public void setLastStatusCheck(Date lastStatusCheck) {
		this.lastStatusCheck = lastStatusCheck;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	private Date lastStatusCheck;
    private String url;

    public ServerStatus(String name, boolean isUp, Date lastStatusCheck, String url) {
        this.name = name;
        this.isUp = isUp;
        this.lastStatusCheck = lastStatusCheck;
        this.url = url;
    }

    public String getUrl() {
        return url;
    }
}


