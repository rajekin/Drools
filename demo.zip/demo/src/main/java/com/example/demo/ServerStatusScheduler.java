//package com.example.demo;
//
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.io.IOException;
//import java.net.HttpURLConnection;
//import java.net.MalformedURLException;
//import java.net.URL;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.mail.SimpleMailMessage;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//@Component
//public class ServerStatusScheduler {
//
//	@Autowired
//	private JavaMailSender emailSender;
//
//	private static final String EMAIL_FROM = "example@gmail.com";
//	private static final String EMAIL_TO = "admin@example.com";
//	private static final String EMAIL_SUBJECT = "Server Unavailable";
//	private static final String EMAIL_TEXT = "The following server is currently unavailable: ";
//
//	@Scheduled(cron = "0 0 * * * *") // Run every hour
//	public void checkServerStatusAndSendEmail() {
//		List<ServerStatus> serverStatusList = new ArrayList<>();
//		try (BufferedReader br = new BufferedReader(
//				new FileReader("C:\\Users\\Raj\\Downloads\\demo (1)\\demo\\src\\main\\resources\\servers.txt"))) {
//			String line;
//			while ((line = br.readLine()) != null) {
//				String[] parts = line.split(",");
//				String name = parts[0].trim();
//				String url = parts[1].trim();
//				try {
//					URL serverUrl = new URL(url);
//					HttpURLConnection conn = (HttpURLConnection) serverUrl.openConnection();
//					conn.setRequestMethod("HEAD");
//					int responseCode = conn.getResponseCode();
//					boolean isUp = (200 <= responseCode && responseCode <= 399);
//					Date lastStatusCheck = new Date(System.currentTimeMillis());
//					ServerStatus serverStatus = new ServerStatus(name, isUp, lastStatusCheck, url);
//					serverStatusList.add(serverStatus);
//				} catch (MalformedURLException e) {
//					// Handle MalformedURLException
//					e.printStackTrace();
//				} catch (IOException e) {
//					// Handle IOException
//					boolean isUp = false;
//					Date lastStatusCheck = new Date(System.currentTimeMillis());
//					ServerStatus serverStatus = new ServerStatus(name, isUp, lastStatusCheck, url);
//					serverStatusList.add(serverStatus);
//					sendEmail(name, url);
//				}
//			}
//		} catch (IOException e) {
//			// Handle IOException
//			e.printStackTrace();
//		}
//	}
//
//	private void sendEmail(String name, String url) {
//		SimpleMailMessage message = new SimpleMailMessage();
//		message.setFrom(EMAIL_FROM);
//		message.setTo(EMAIL_TO);
//		message.setSubject(EMAIL_SUBJECT);
//		message.setText(EMAIL_TEXT + name + " (" + url + ")");
//		emailSender.send(message);
//	}
//}
