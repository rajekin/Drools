package net.codejava;

import java.time.LocalDateTime;
import java.util.Date;

public class ServerStatus {
    private String name;
    private boolean isUp;
    private LocalDateTime lastStatusCheck;
    private String url;	

    public ServerStatus(String name, boolean isUp, LocalDateTime lastStatusCheck, String url) {
        this.name = name;
        this.isUp = isUp;
        this.lastStatusCheck = lastStatusCheck;
        this.url = url;
       
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isUp() {
        return isUp;
    }

    public void setUp(boolean up) {
        isUp = up;
    }

    public LocalDateTime getLastStatusCheck() {
        return lastStatusCheck;
    }

    public void setLastStatusCheck(LocalDateTime lastStatusCheck) {
        this.lastStatusCheck = lastStatusCheck;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

  
}
