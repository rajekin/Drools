package net.codejava;

import java.util.List;

public class EventAnalytics {

    private String eventName;
    private double totalRuleCoverage;
    private List<EventCoverage> eventCoverages;
    private List<String> unexecutedRules;

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public double getTotalRuleCoverage() {
        return totalRuleCoverage;
    }

    public void setTotalRuleCoverage(double totalRuleCoverage) {
        this.totalRuleCoverage = totalRuleCoverage;
    }

    public List<EventCoverage> getEventCoverages() {
        return eventCoverages;
    }

    public void setEventCoverages(List<EventCoverage> eventCoverages) {
        this.eventCoverages = eventCoverages;
    }

    public List<String> getUnexecutedRules() {
        return unexecutedRules;
    }

    public void setUnexecutedRules(List<String> unexecutedRules) {
        this.unexecutedRules = unexecutedRules;
    }

    public int getTotalExecutedRules() {
        int totalExecutedRules = 0;
        if (eventCoverages != null) {
            for (EventCoverage eventCoverage : eventCoverages) {
                totalExecutedRules += eventCoverage.getExecutedRules();
            }
        }
        return totalExecutedRules;
    }

    public int getTotalRules() {
        int totalRules = 0;
        if (eventCoverages != null) {
            for (EventCoverage eventCoverage : eventCoverages) {
                totalRules += eventCoverage.getTotalRules();
            }
        }
        return totalRules;
    }
}
