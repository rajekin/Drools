package net.codejava;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class EventAnalyticsController {

    @GetMapping("/event")
    public String getEventAnalytics(Model model) {
        List<String> fileNames = Arrays.asList("file.txt", "file1.txt"); // Update with your file names
        List<EventAnalytics> eventAnalyticsList = new ArrayList<>();

        for (String fileName : fileNames) {
            String fileContent = readFileContentFromClasspath(fileName);
            EventAnalytics eventAnalytics = extractEventAnalytics(fileContent);
            eventAnalyticsList.add(eventAnalytics);
        }

        model.addAttribute("eventAnalyticsList", eventAnalyticsList);
        return "event";
    }

    private String readFileContentFromClasspath(String fileName) {
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(fileName)) {
            if (inputStream != null) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                return reader.lines().collect(Collectors.joining(System.lineSeparator()));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return ""; // Return empty string or handle the error appropriately
    }

    private EventAnalytics extractEventAnalytics(String fileContent) {
        EventAnalytics eventAnalytics = new EventAnalytics();
        eventAnalytics.setEventName(extractEventName(fileContent));
        eventAnalytics.setTotalRuleCoverage(extractTotalRuleCoverage(fileContent));
        eventAnalytics.setEventCoverages(extractEventCoverages(fileContent));
        eventAnalytics.setUnexecutedRules(extractUnexecutedRules(fileContent));
        return eventAnalytics;
    }

    private String extractEventName(String fileContent) {
        int eventNameIndex = fileContent.indexOf("Event Name:") + 11;
        int totalRuleCoverageIndex = fileContent.indexOf("Total Rule Coverage:");

        // Check if the indices are valid
        if (eventNameIndex >= 0 && totalRuleCoverageIndex >= 0) {
            return fileContent.substring(eventNameIndex, totalRuleCoverageIndex).trim();
        } else {
            // Handle the error appropriately, such as returning a default value
            return "Unknown Event Name";
        }
    }

    private double extractTotalRuleCoverage(String fileContent) {
        int totalRuleCoverageIndex = fileContent.indexOf("Total Rule Coverage:") + 20;
        int coveragePercentageEndIndex = fileContent.indexOf("%", totalRuleCoverageIndex);

        // Check if the indices are valid
        if (totalRuleCoverageIndex >= 0 && coveragePercentageEndIndex >= 0 && totalRuleCoverageIndex < coveragePercentageEndIndex) {
            String coveragePercentage = fileContent.substring(totalRuleCoverageIndex, coveragePercentageEndIndex).trim();
            try {
                return Double.parseDouble(coveragePercentage);
            } catch (NumberFormatException e) {
                // Handle the parsing error, such as returning a default value
                return 0.0;
            }
        } else {
            // Handle the error appropriately, such as returning a default value
            return 0.0;
        }
    }

    private List<EventCoverage> extractEventCoverages(String fileContent) {
        List<EventCoverage> eventCoverages = new ArrayList<>();
        int eventCoverageIndex = fileContent.indexOf("Event Coverage:");
        int unexecutedRulesIndex = fileContent.indexOf("Rules that were not executed during tests:");

        // Check if the sections exist in the file content
        if (eventCoverageIndex >= 0 && unexecutedRulesIndex >= 0 && eventCoverageIndex < unexecutedRulesIndex) {
            String eventCoverageSection = fileContent.substring(eventCoverageIndex, unexecutedRulesIndex).trim();
            String[] lines = eventCoverageSection.split("\n");

            for (String line : lines) {
                if (!line.trim().isEmpty()) {
                    String[] parts = line.split(":");
                    if (parts.length == 2) {
                        String event = parts[0].trim();
                        String coverageInfo = parts[1].trim();

                        String coveragePercentage = extractCoveragePercentage(coverageInfo);
                        int executedRules = extractExecutedRules(coverageInfo);
                        int totalRules = extractTotalRules(coverageInfo);

                        eventCoverages.add(new EventCoverage(event, Double.parseDouble(coveragePercentage),
                                executedRules, totalRules));
                    }
                }
            }
        }

        return eventCoverages;
    }

    private String extractCoveragePercentage(String coverageInfo) {
        String coveragePercentage = "";
        int coveragePercentageStartIndex = coverageInfo.indexOf("(");
        int coveragePercentageEndIndex = coverageInfo.indexOf("%");
        if (coveragePercentageStartIndex >= 0 && coveragePercentageEndIndex >= 0 && coveragePercentageStartIndex < coveragePercentageEndIndex) {
            coveragePercentage = coverageInfo.substring(coveragePercentageStartIndex + 1, coveragePercentageEndIndex).trim();
        }
        return coveragePercentage;
    }

    private int extractExecutedRules(String coverageInfo) {
        int executedRules = 0;
        int executedRulesStartIndex = coverageInfo.indexOf("(");
        int executedRulesEndIndex = coverageInfo.indexOf(" of");
        if (executedRulesStartIndex >= 0 && executedRulesEndIndex >= 0 && executedRulesStartIndex < executedRulesEndIndex) {
            String executedRulesStr = coverageInfo.substring(executedRulesStartIndex + 1, executedRulesEndIndex).trim();
            executedRules = Integer.parseInt(executedRulesStr);
        }
        return executedRules;
    }

    private int extractTotalRules(String coverageInfo) {
        int totalRules = 0;
        int totalRulesStartIndex = coverageInfo.lastIndexOf("of") + 3;
        int totalRulesEndIndex = coverageInfo.lastIndexOf("Rules");
        if (totalRulesStartIndex >= 0 && totalRulesEndIndex >= 0 && totalRulesStartIndex < totalRulesEndIndex) {
            String totalRulesStr = coverageInfo.substring(totalRulesStartIndex, totalRulesEndIndex).trim();
            totalRules = Integer.parseInt(totalRulesStr);
        }
        return totalRules;
    }

    private List<String> extractUnexecutedRules(String fileContent) {
        int unexecutedRulesIndex = fileContent.indexOf("Rules that were not executed during tests:");
        String unexecutedRulesSection = fileContent.substring(unexecutedRulesIndex);

        List<String> unexecutedRules = new ArrayList<>();
        String[] lines = unexecutedRulesSection.split("\n");

        for (String line : lines) {
            if (!line.startsWith("Rules that were not executed during tests:")) {
                unexecutedRules.add(line.trim());
            }
        }

        return unexecutedRules;
    }

    private List<String> getPieChartLabels(EventAnalytics eventAnalytics) {
        List<String> labels = new ArrayList<>();
        labels.add("Executed Rules");
        labels.add("Unexecuted Rules");
        return labels;
    }

    private List<Integer> getPieChartData(EventAnalytics eventAnalytics) {
        List<Integer> data = new ArrayList<>();
        data.add(eventAnalytics.getTotalExecutedRules());
        data.add(eventAnalytics.getTotalRules() - eventAnalytics.getTotalExecutedRules());
        return data;
    }

    @GetMapping("/event/coverage")
    public String eventCoverage(Model model) {
        // Add any necessary data to the model
        return "eventcoverage";
    }
}
