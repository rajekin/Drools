package net.codejava;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Controller
public class EventAnalyticsController {

    @GetMapping("/event")
    public String getEventAnalytics(Model model) {
        String filePath = "file.txt";
        String fileContent = readFileContent(filePath);
        EventAnalytics eventAnalytics = extractEventAnalytics(fileContent);
        model.addAttribute("eventAnalytics", eventAnalytics);
        model.addAttribute("pieChartLabels", getPieChartLabels(eventAnalytics));
        model.addAttribute("pieChartData", getPieChartData(eventAnalytics));
        return "event";
    }

    private String readFileContent(String filePath) {
        try {
            return new String(Files.readAllBytes(Paths.get(filePath)));
        } catch (IOException e) {
            e.printStackTrace();
            return ""; // Return empty string or handle the error appropriately
        }
    }

    private EventAnalytics extractEventAnalytics(String fileContent) {
        EventAnalytics eventAnalytics = new EventAnalytics();
        eventAnalytics.setEventName(extractEventName(fileContent));
        eventAnalytics.setTotalRuleCoverage(extractTotalRuleCoverage(fileContent));
        eventAnalytics.setEventCoverages(extractEventCoverages(fileContent));
        eventAnalytics.setUnexecutedRules(extractUnexecutedRules(fileContent));
        return eventAnalytics;
    }

    private String extractEventName(String fileContent) {
        int eventNameIndex = fileContent.indexOf("Event Name:") + 12;
        int totalRuleCoverageIndex = fileContent.indexOf("Total Rule Coverage:");
        return fileContent.substring(eventNameIndex, totalRuleCoverageIndex).trim();
    }

    private double extractTotalRuleCoverage(String fileContent) {
        int totalRuleCoverageIndex = fileContent.indexOf("Total Rule Coverage:") + 20;
        int coveragePercentageEndIndex = fileContent.indexOf("%", totalRuleCoverageIndex);
        String coveragePercentage = fileContent.substring(totalRuleCoverageIndex, coveragePercentageEndIndex).trim();
        return Double.parseDouble(coveragePercentage);
    }

    private List<EventCoverage> extractEventCoverages(String fileContent) {
        int eventCoverageIndex = fileContent.indexOf("Event Coverage:") + 16;
        int unexecutedRulesIndex = fileContent.indexOf("Rules that were not executed during tests:");
        String eventCoverageSection = fileContent.substring(eventCoverageIndex, unexecutedRulesIndex).trim();

        List<EventCoverage> eventCoverages = new ArrayList<>();
        String[] lines = eventCoverageSection.split("\n");

        for (String line : lines) {
            if (!line.trim().isEmpty()) {
                String[] parts = line.split(":");
                String event = parts[0].trim();
                String coverageInfo = parts[1].trim();

                int coveragePercentageEndIndex = coverageInfo.indexOf("%");
                String coveragePercentage = coverageInfo.substring(0, coveragePercentageEndIndex).trim();

                int executedRulesStartIndex = coverageInfo.indexOf("(") + 1;
                int executedRulesEndIndex = coverageInfo.indexOf(" of");
                String executedRules = coverageInfo.substring(executedRulesStartIndex, executedRulesEndIndex).trim();

                int totalRulesStartIndex = executedRulesEndIndex + 4;
                int totalRulesEndIndex = coverageInfo.lastIndexOf("Rules");
                String totalRules = coverageInfo.substring(totalRulesStartIndex, totalRulesEndIndex).trim();

                eventCoverages.add(new EventCoverage(event, Double.parseDouble(coveragePercentage),
                        Integer.parseInt(executedRules), Integer.parseInt(totalRules)));
            }
        }

        return eventCoverages;
    }

    private List<String> extractUnexecutedRules(String fileContent) {
        int unexecutedRulesIndex = fileContent.indexOf("Rules that were not executed during tests:");
        String unexecutedRulesSection = fileContent.substring(unexecutedRulesIndex);

        List<String> unexecutedRules = new ArrayList<>();
        String[] lines = unexecutedRulesSection.split("\n");

        for (String line : lines) {
            if (!line.startsWith("Rules that were not executed during tests:")) {
                unexecutedRules.add(line.trim());
            }
        }

        return unexecutedRules;
    }

    private List<String> getPieChartLabels(EventAnalytics eventAnalytics) {
        List<String> labels = new ArrayList<>();
        labels.add("Executed Rules");
        labels.add("Unexecuted Rules");
        return labels;
    }

    private List<Integer> getPieChartData(EventAnalytics eventAnalytics) {
        List<Integer> data = new ArrayList<>();
        data.add(eventAnalytics.getTotalExecutedRules());
        data.add(eventAnalytics.getTotalRules() - eventAnalytics.getTotalExecutedRules());
        return data;
    }
    
    @GetMapping("/event/coverage")
    public String eventCoverage(Model model) {
        // Add any necessary data to the model
        return "eventcoverage";
    }

}
