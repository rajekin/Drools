package net.codejava;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.springframework.stereotype.Service;

@Service
public class FileBasedUserService implements UserService {

    private static final String USER_DETAILS_FILE_PATH = "user_details.txt";

    private Map<String, String> userMap = new HashMap<>();

    public FileBasedUserService() {
        try {
            File userDetailsFile = new File(USER_DETAILS_FILE_PATH);
            Scanner scanner = new Scanner(userDetailsFile);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] userDetails = line.split(",");
                userMap.put(userDetails[0], userDetails[1]);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean isValidUser(String username, String password) {
        String expectedPassword = userMap.get(username);
        return expectedPassword != null && expectedPassword.equals(password);
    }

	@Override
	public void saveUser(User user) {
		// TODO Auto-generated method stub
		
	}
}
