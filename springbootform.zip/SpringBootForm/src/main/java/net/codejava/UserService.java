package net.codejava;

public interface UserService {
    boolean isValidUser(String username, String password);
    void saveUser(User user);
}

