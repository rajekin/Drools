package net.codejava;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

public class EventCoverage {
    private String event;
    private double coverage;
    private int executedRules;
    private int totalRules;
    private List<EventCoverage> childEventCoverages;

    public EventCoverage(String event, double coverage, int executedRules, int totalRules) {
        this.event = event;
        this.coverage = coverage;
        this.executedRules = executedRules;
        this.totalRules = totalRules;
        this.childEventCoverages = new ArrayList<>();
    }

    // Getters and setters

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public double getCoverage() {
        return coverage;
    }

    public void setCoverage(double coverage) {
        this.coverage = coverage;
    }

    public int getExecutedRules() {
        return executedRules;
    }

    public void setExecutedRules(int executedRules) {
        this.executedRules = executedRules;
    }

    public int getTotalRules() {
        return totalRules;
    }

    public void setTotalRules(int totalRules) {
        this.totalRules = totalRules;
    }

    public List<EventCoverage> getChildEventCoverages() {
        return childEventCoverages;
    }

    public void setChildEventCoverages(List<EventCoverage> childEventCoverages) {
        this.childEventCoverages = childEventCoverages;
    }
}


