package net.codejava.notification;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class EmailNotificationScheduler {

    private final JavaMailSender javaMailSender;

    @Autowired
    public EmailNotificationScheduler(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    @Scheduled(cron = "0 */2 * * * *")
    public void sendEmailNotification() {
        String recipient = "decisionservernotify@gmail.com"; // Replace with the recipient email address
        String subject = "Server Downtime Notification";

        // Check the server status and update downtime count
        List<String> downServers = getDownServers();

        // Send email only if there are down servers
        if (!downServers.isEmpty()) {
            StringBuilder emailContent = new StringBuilder("Server Downtime Notification\n\n");
            emailContent.append("The following servers are currently down:\n");
            for (String server : downServers) {
                emailContent.append("- ").append(server).append("\n");
            }

            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(recipient);
            message.setSubject(subject);
            message.setText(emailContent.toString());

            javaMailSender.send(message);
        }
    }

    private List<String> getDownServers() {
        List<String> downServers = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("servers.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[0].trim();
                String url = parts[1].trim();
                try {
                	 URL serverUrl = new URL(url);
                     HttpURLConnection conn = (HttpURLConnection) serverUrl.openConnection();
                     if (conn instanceof HttpsURLConnection) {
                         // Disable SSL certificate validation
                         ((HttpsURLConnection) conn).setSSLSocketFactory(createTrustAllSSLSocketFactory());
                         ((HttpsURLConnection) conn).setHostnameVerifier((hostname, session) -> true);
                     }

                     conn.setRequestMethod("HEAD");
                     int responseCode = conn.getResponseCode();
                    boolean isUp = (200 <= responseCode && responseCode <= 399);
                    if (!isUp) {
                        downServers.add(name);
                    }
                } catch (MalformedURLException e) {
                    // Handle MalformedURLException
                    e.printStackTrace();
                } catch (IOException e) {
                    // Handle IOException
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            // Handle IOException
            e.printStackTrace();
        }
        return downServers;
    }
    
    private SSLSocketFactory createTrustAllSSLSocketFactory() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        }

                        public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        }
                    }
            };
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            return sslContext.getSocketFactory();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
